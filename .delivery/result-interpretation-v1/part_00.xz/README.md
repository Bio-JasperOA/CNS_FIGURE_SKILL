# CNS Result Interpretation · v3-compatible extension

This package adds a source-linked **results-interpret** module to the existing CNS_FIGURE_SKILL repository. It leaves plotting code, palettes and generated figures unchanged. It can be applied with or without the preceding data-adaptation extension and preserves an existing data-adapt route.

The module is an agent workflow for biological interpretation, paired with a tested structural/evidence-declaration validator. It is not an automatic mechanism-discovery engine. The included results are synthetic teaching examples.

## Apply to an existing checkout

```bash
# Inspect planned changes without writing.
python apply_to_checkout.py --repo /path/to/CNS_FIGURE_SKILL

# Apply to the existing checkout, with backups of modified files.
python apply_to_checkout.py --repo /path/to/CNS_FIGURE_SKILL --apply
```

The installer adds `singlecell-spatial-figures/result_interpretation/` and synchronizes the root README, AGENTS, STRATEGY_ROUTES, route validator, analysis-execution handoff and capability declaration where present. It does not replace the repository, remove existing routes, or change the v3 major version. Unexpected router structure or affected local tracked edits cause an explicit stop instead of silent overwrite.

After applying, run from the repository root:

```bash
python .github/scripts/validate_strategy_routes.py --self-test
python -m unittest discover -s singlecell-spatial-figures/result_interpretation/tests -v
```

Use the root README addition for the full invocation prompt. No unrequested biological analysis, image generation or publication of user results occurs.

## Read first

- [Core Skill](singlecell-spatial-figures/result_interpretation/SKILL.md)
- [Assay-aware reasoning](singlecell-spatial-figures/result_interpretation/ASSAY_PLAYBOOK.md)
- [Narrative patterns and worked interpretation](singlecell-spatial-figures/result_interpretation/NARRATIVE_PLAYBOOK.md)
- [Literature access and reasoning patterns](singlecell-spatial-figures/result_interpretation/LITERATURE_LOGIC.md)
- [Root README addition](ROOT_README_ADDITION.md)
- [Local validation](LOCAL_TEST_REPORT.txt)

The five-result worked example separates disease-associated abundance/programme, tissue localization, molecular perturbation response and an unresolved functional endpoint. A second example shows how to interpret a negative model benchmark without claiming equivalence or universal AI failure.
